import requests
import logging
import sys
import uuid
from db_files.db_service import DbService
from db_files.db_context import User
from config import NEWS_API_KEY

db = DbService()
user_session = None


def session_create():
    print("Здравствуйте! Выберите номер действия.")
    print("1. Регистрация.")
    print("2. Вход.")

    choice = input()

    if choice == "1":
        username = input("Введите свои имя: ")
        password = input("Введите пароль: ")
        user_id = str(uuid.uuid4())

        db.insert_user(user_id, username, password)
        user = User(id=user_id, username=username, password=password)
        print("Вы успешно зарегались!")
        return user
    elif choice == "2":
        username = input("Введите свои имя: ")
        password = input("Введите пароль: ")

        user = db.get_user(username)
        if user is not None and user.password == password:
            print("Добро пожаловать!")
            return user
        else:
            print("Неправильный логин или пароль")
    else:
        print("Вы выбрали неправильную команду, пожалуйста попробуйте еще раз.")


def show_more_info_article(article):
    print(f'Заголовок: {article.title}')
    print(f'Описание: {article.content}')
    print(f'Дата создания: {article.created_at}')
    print(len(list(article.comments)))

    if len(list(article.comments)) == 0:
        print("Этот пост пока не комментировали.")
    else:
        print("Комментарии к посту: ")
        for comment in article.comments:
            print(f'{comment.user.username}: {comment.content}')

    choice = input("Хотите добавить комментарий в этот пост? Ваше мнение важно! (д/н): ")

    if choice.lower() in ["да", "д", "yes", "y"]:
        content = input("Введите ваш комментарий: ")
        db.insert_new_comment(content, user_session.id, article.id)
    else:
        article_menu()


def show_news(language, key_word, searchin=None):
    if searchin is not None:
        if searchin == "1":
            link = (f'https://newsapi.org/v2/everything?q={key_word}&apiKey={NEWS_API_KEY}&language={language}'
                    f'&searchin=title')
        elif searchin == "2":
            link = (f'https://newsapi.org/v2/everything?q={key_word}&apiKey={NEWS_API_KEY}&language={language}'
                    f'&searchin=description')
        else:
            link = f'https://newsapi.org/v2/everything?q={key_word}&apiKey={NEWS_API_KEY}&language={language}'
            logging.error("Не правильно была введена команда для поиска новостей")
    else:
        link = f'https://newsapi.org/v2/everything?q={key_word}&apiKey={NEWS_API_KEY}&language={language}'

    response = requests.get(link)

    if response.status_code == 200:
        data = response.json()
        articles = data.get('articles', [])

        if articles:
            for news in articles:
                print(f'Заголовок: {news.get("title", "Нет данных")}')
                print(f'Описание: {news.get("description", "Нет данных")}')
                print(f'Дата выпуска: {news.get("publishedAt", "Нет данных")}')
                print(f'Ссылка на первоисточник: {news.get("url", "Нет данных")}')
                print('---')
        else:
            print("Не было найдено новостей по ключевому слову")

    else:
        logging.error(f"Ошибка запроса к News API: {response.status_code}")


def article_menu():
    while True:
        print("1. Добавить свой пост.")
        print("2. Посмотреть список постов пользователей.")
        print("3. Посмотреть список новостей.")
        print("4. Выход.")

        choice = input("Выберите номер команды: ")
        articles = db.get_articles()

        if choice == "1":
            title = input("Введите заголовок: ")
            content = input("Введите описание: ")

            db.insert_new_article(title, content, user_session.id)
            print("Вы успешно добавили новый пост!")
            article_menu()
        elif choice == "2":
            i = 1
            for article in articles:
                print(f'{i} - {article.title}')
                i += 1

            try:
                article_choice = int(input("Который хотите посмотреть? Выберите номер. Для выхода наберите 0: "))

                if article_choice == 0:
                    print("Выход.")
                    sys.exit()
                else:
                    article = articles[article_choice - 1]
                    show_more_info_article(article)
            except Exception as e:
                logging.error(f'Ошибка - {e}')
        elif choice == "3":
            language = input("Введите код языка статьи (ru, en, ...): ")
            key_word = input("Введите ключевое слово для поиска новостей: ")
            while True:
                searchin = input(
                    "Хотите искать именно в заголовках или в описании? Нажмите Enter, если не важно где искать.\n"
                    "Наберите 1, если хотите искать в заголовках, и 2, если в описании: ")

                if searchin in {"", "1", "2"}:
                    break
                else:
                    print("Неправильный ввод. Введите 1 или 2, или нажмите Enter.")
                    
            show_news(language, key_word, searchin)
        elif choice == "4":
            sys.exit()
        else:
            print("Вы выбрали неправильную команду, пожалуйста попробуйте еще раз.")


if __name__ == "__main__":
    while user_session is None:
        user_session = session_create()

    article_menu()
