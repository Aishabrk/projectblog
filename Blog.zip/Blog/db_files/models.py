import uuid

from sqlalchemy import MetaData, Table, Column, String, Text, TIMESTAMP, ForeignKey

metadata = MetaData()

users = Table(
    "users",
    metadata,
    Column("id", String, primary_key=True, default=str(uuid.uuid4), unique=True, nullable=False),
    Column("username", String, nullable=False),
    Column("password", String, nullable=False)
)

articles = Table(
    "articles",
    metadata,
    Column("id", String, primary_key=True, default=str(uuid.uuid4), unique=True, nullable=False),
    Column("title", String, nullable=False),
    Column("content", Text, nullable=False),
    Column("user_id", String, ForeignKey("users.id")),
    Column("created_at", TIMESTAMP, nullable=False)
)

comments = Table(
    "comments",
    metadata,
    Column("id", String, primary_key=True, default=str(uuid.uuid4), unique=True, nullable=False),
    Column("content", Text, nullable=False),
    Column("user_id", String, ForeignKey("users.id")),
    Column("article_id", String, ForeignKey("articles.id")),
    Column("created_at", TIMESTAMP, nullable=False)
)
