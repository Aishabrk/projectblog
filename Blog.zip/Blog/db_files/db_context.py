import uuid

from sqlalchemy import Column, String, Text, TIMESTAMP, ForeignKey
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import relationship

Base = declarative_base()


class User(Base):
    __tablename__ = 'users'

    id = Column(String, primary_key=True, default=str(uuid.uuid4), unique=True, nullable=False)
    username = Column(String, nullable=False)
    password = Column(String, nullable=False)

    articles = relationship("Article", back_populates="user")
    comments = relationship("Comment", back_populates="user")


class Article(Base):
    __tablename__ = 'articles'

    id = Column(String, primary_key=True, default=str(uuid.uuid4), unique=True, nullable=False)
    title = Column(String, nullable=False)
    content = Column(Text, nullable=False)
    user_id = Column(String, ForeignKey("users.id"))
    created_at = Column(TIMESTAMP, nullable=False)

    user = relationship("User", back_populates="articles")
    comments = relationship("Comment", back_populates="article")


class Comment(Base):
    __tablename__ = 'comments'

    id = Column(String, primary_key=True, default=str(uuid.uuid4), unique=True, nullable=False)
    content = Column(Text, nullable=False)
    user_id = Column(String, ForeignKey("users.id"))
    article_id = Column(String, ForeignKey("articles.id"))
    created_at = Column(TIMESTAMP, nullable=False)

    user = relationship("User", back_populates="comments")
    article = relationship("Article", back_populates="comments")
