import datetime
import logging
import uuid

from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

from db_files.db_context import Article, Comment, User

logging.basicConfig(filename="../logs.txt", level=logging.INFO)


class DbService:
    def __init__(self):
        self.engine = None
        self.Session = None
        self.session = None
        self.initialize_database()

    def initialize_database(self):
        try:
            self.engine = create_engine('sqlite:///blog.db')
            self.Session = sessionmaker(bind=self.engine)
            self.session = self.Session()
        except Exception as e:
            logging.error(f"Ошибка при создании базы данных: {e}")

    def insert_user(self, user_id, username, password):
        try:
            new_user = User(id=user_id, username=username, password=password)
            self.session.add(new_user)
            self.session.commit()

        except Exception as e:
            logging.error(f'Ошибка: {e}')

    def get_user(self, username):
        try:
            user = self.session.query(User).filter(User.username == username).first()
            return user
        except Exception as e:
            logging.error(f'Ошибка: {e}')

    def insert_new_article(self, title, content, user_id):
        try:
            new_article = Article(id=str(uuid.uuid4()), title=title, content=content,
                                  created_at=datetime.datetime.now(), user_id=user_id)
            self.session.add(new_article)
            self.session.commit()
            logging.info("УСПЕХ")

        except Exception as e:
            logging.error(f'Ошибка: {e}')

    def get_articles(self):
        try:
            articles = self.session.query(Article).all()
            return articles

        except Exception as e:
            logging.error(f'Ошибка: {e}')

    def insert_new_comment(self, content, user_id, article_id):
        try:
            new_comment = Comment(id=str(uuid.uuid4()), content=content, user_id=user_id,
                                  article_id=article_id, created_at=datetime.datetime.now())
            self.session.add(new_comment)
            self.session.commit()
            logging.info("УСПЕХ")
        except Exception as e:
            logging.error(f"Ошибка: {e}")
            return False

    def __del__(self):
        if self.session:
            self.session.close()


# для теста сервиса для работы с базой данных
if __name__ == "__main__":
    db = DbService()
    db.insert_new_comment("согласен", "cc9d5b31-27ca-4d42-9761-ac45f56f3fd7", "eafe2163-5d15-4902-9a70-8134f2376879")
