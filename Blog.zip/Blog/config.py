from dotenv import load_dotenv
import os

load_dotenv()

NEWS_API_KEY = os.environ.get("NEWS_API_KEY")
